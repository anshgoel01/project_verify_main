import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: corsHeaders });

    const adminClient = createClient(supabaseUrl, serviceKey);
    const { data: isAdmin } = await adminClient.rpc("is_admin", { _user_id: user.id });
    if (!isAdmin) return new Response(JSON.stringify({ error: "Forbidden" }), { status: 403, headers: corsHeaders });

    // Fetch stats
    const [profilesRes, submissionsRes, collegesRes] = await Promise.all([
      adminClient.from("profiles").select("id", { count: "exact", head: true }),
      adminClient.from("submissions").select("status"),
      adminClient.from("profiles").select("college_id, score, correct_submissions, total_submissions, colleges(name)")
        .gt("total_submissions", 0),
    ]);

    const totalStudents = profilesRes.count || 0;
    const submissions = submissionsRes.data || [];
    const totalSubmissions = submissions.length;
    const correctCount = submissions.filter((s: any) => s.status === "correct").length;
    const wrongCount = submissions.filter((s: any) => s.status === "wrong").length;
    const processingCount = submissions.filter((s: any) => s.status === "processing").length;
    const skippedCount = submissions.filter((s: any) => s.status === "skipped" || s.status === "failed").length;

    // College-wise performance
    const collegeMap = new Map<string, { name: string; students: number; correct: number; total: number; score: number }>();
    for (const p of (collegesRes.data || []) as any[]) {
      const cName = p.colleges?.name || "Unknown";
      const cId = p.college_id;
      if (!collegeMap.has(cId)) {
        collegeMap.set(cId, { name: cName, students: 0, correct: 0, total: 0, score: 0 });
      }
      const c = collegeMap.get(cId)!;
      c.students++;
      c.correct += p.correct_submissions;
      c.total += p.total_submissions;
      c.score += p.score;
    }

    return new Response(JSON.stringify({
      totalStudents,
      totalSubmissions,
      correctCount,
      wrongCount,
      processingCount,
      skippedCount,
      collegePerformance: Array.from(collegeMap.values()),
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), { status: 500, headers: corsHeaders });
  }
});
